export default Math.random();
