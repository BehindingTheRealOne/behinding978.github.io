export default new Map([
    ["py", "pyodide"],
    ["mpy", "micropython"],
]);
