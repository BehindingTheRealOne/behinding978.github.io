// @see https://github.com/jsdelivr/jsdelivr/issues/18528
export * from "./core/dist/core.js";
